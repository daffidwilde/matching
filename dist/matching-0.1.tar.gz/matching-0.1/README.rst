# Matching
==========

A package for solving matching games with the Gale-Shapley algorithm.
---------------------------------------------------------------------

